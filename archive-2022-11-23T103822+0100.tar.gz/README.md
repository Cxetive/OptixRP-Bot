<h1 align="center">LYXCODE PREMIUM</h1>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-1.0.1-blue.svg?cacheSeconds=2592000" />
  <a href="#" target="_blank">
    <img alt="License: ISC" src="https://img.shields.io/badge/License-ISC-yellow.svg" />
  </a>
</p>

> This is the official repository for Lyxcode's youtube series.

## Required Installations

```sh
npm i discord.js
npm i ascii-table
```

## Required Configuration

```sh
config.json
```

## Features

```sh
- None
```

## Author

👤 **Lyxcode**

- Github: [@iLyxcode](https://github.com/LyxcodeNet)
- Youtube: [@Lyxcode](https://www.youtube.com/c/lyxcode)
- Discord: [@Lyxcode Community](https://discord.gg/YJGN7t5947)

## Show your support

Give a ⭐️ if this project helped you!

<a href="https://ko-fi.com/I2I15YHBW">
  <img src="https://ko-fi.com/img/githubbutton_sm.svg" width="160">
</a>

---
